<template>
  <div> 
    <fbook />
  </div>
</template>
<script>
import fbook from "./fbook.vue"
export default {
  components: { fbook }
}
</script>

 
 